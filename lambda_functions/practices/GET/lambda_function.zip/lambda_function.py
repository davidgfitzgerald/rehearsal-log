import logging
from pymysql import connect, cursors
from DBAccessData import rehearsal_log_db

# Logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def lambda_handler(event, context):
    try:
        # Connect to DB
        connection = connect(**rehearsal_log_db())
        logger.debug("SUCCESS: Connection to MySQL database succeeded")
    except Exception as e:
        raise e

    with connection.cursor(cursors.DictCursor) as cur:
        try:
            sql_query = 'SELECT * from practices'
            cur.execute(sql_query)
            connection.commit()

            return cur.fetchall()

        except Exception as e:
            connection.rollback()
            raise e


if __name__ == '__main__':
    lambda_handler(None, None)
