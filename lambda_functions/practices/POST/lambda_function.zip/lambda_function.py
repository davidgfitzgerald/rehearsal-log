import logging
from pymysql import connect, cursors
from DBAccessData import rehearsal_log_db

# Logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def lambda_handler(event, context):
    try:
        duration = event["duration"]
        bpm = event["bpm"]
        exercise_id = event["exercise_id"]
    except KeyError as e:
        logging.error(f"Key {e} missing from payload")
        raise e

    try:
        connection = connect(**rehearsal_log_db())
        logger.debug("SUCCESS: Connection to MySQL database succeeded")
    except Exception as e:
        raise e

    with connection.cursor(cursors.DictCursor) as cur:
        try:
            create_practice_query = "INSERT INTO practices (duration, bpm, exercise_id) " \
                        "values (%s, %s, %s)"
            cur.execute(create_practice_query, (duration, bpm, exercise_id))
            connection.commit()

            get_practice_query = "SELECT * FROM practices WHERE id=%s"
            cur.execute(get_practice_query, cur.lastrowid)

            for row in cur:
                return row

        except Exception as e:
            connection.rollback()
            raise e


if __name__ == '__main__':
    ev = {
        "duration": "999",
        "instrument": "drums",
        "bpm": "99",
        "exercise_id": "1"
    }

    res = lambda_handler(ev, None)
    logging.info("Practice created")
    logging.info(f"Response: {res}")
