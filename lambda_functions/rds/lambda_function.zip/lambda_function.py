import boto3
import logging

# Logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def lambda_handler(event, context):
    access_data = {
        "RDS_ENDPOINT": "rehearsal-log.cdlltxeggpnv.us-east-2.rds.amazonaws.com",
        "RDS_PORT": 3306,
        "USERNAME": 'dbaccess',
        "DATABASE_NAME": "rehearsal_log",
        "SSL": {'ca': 'rds-combined-ca-bundle.pem'}
    }

    try:
        # Auth Token
        rds_client = boto3.client('rds')
        auth_token = rds_client.generate_db_auth_token(access_data["RDS_ENDPOINT"],
                                                       access_data["RDS_PORT"],
                                                       access_data["USERNAME"])
        access_data["AUTH_TOKEN"] = auth_token

        logger.debug(f"Response from generate_db_auth_token:\n {auth_token}")
        return access_data

    except Exception as e:
        logger.error(e)
        raise e


if __name__ == '__main__':
    access_data = lambda_handler(None, None)
    print(access_data)
